export const mapServices = [
  {
    name: 'OpenStreetMap',
    attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors pap',
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
  }
];
